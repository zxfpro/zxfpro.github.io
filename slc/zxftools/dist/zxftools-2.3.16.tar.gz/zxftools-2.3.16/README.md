# zxftools

#### 介绍
个人工具包



#### 安装教程
```
pip install git+https://oauth2:513d7048d56d1c7b80f025965648ff0d@gitee.com/zhaoxuefeng199508/zxftools.git
```
```
git+https://oauth2:513d7048d56d1c7b80f025965648ff0d@gitee.com/zhaoxuefeng199508/zxftools.git
```
```
pip install git+https://oauth2:513d7048d56d1c7b80f025965648ff0d@gitee.com/zhaoxuefeng199508/qet.git
```
