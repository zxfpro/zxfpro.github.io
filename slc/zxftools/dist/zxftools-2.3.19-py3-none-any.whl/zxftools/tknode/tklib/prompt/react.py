#gpt -4 不好用
# gpt-4 效果很好

控制字数 = """
please step by step!
-step 1 你首先应该使用write_story 去编写一个故事
-step 2 你应该使用word_count 来计算故事的字数
-step 3 如果字数满足条件,你应该将故事输出给用户. 如果字数不满足,你应该重新生成故事

使用中文编写一篇鬼故事, 要求: 字数小于300字
"""


