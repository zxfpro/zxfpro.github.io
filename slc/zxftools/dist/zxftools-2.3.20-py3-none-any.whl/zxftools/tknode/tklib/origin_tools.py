

#
# pfile = PythonFileToolSpec('aas.py')
#
# pfile.get_function('TestSave')
from llama_hub.tools.python_file import PythonFileToolSpec
from llama_hub.tools.code_interpreter import CodeInterpreterToolSpec
from llama_hub.tools.arxiv import ArxivToolSpec
from llama_hub.tools.azure_speech import AzureSpeechToolSpec
from llama_hub.tools.bing_search import BingSearchToolSpec


