# 兼顾稳定性和测速
from .llms import get_llm
from .multi_modal_llms import get_multi_modal_llms
